from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import jwt
from datetime import datetime, timedelta

app = FastAPI()

# 🔐 Secret key (You can copy from Django settings.py)
SECRET_KEY = 'django-insecure-fg&a9bxmj0)2zw*zq79q-y19%feb($1$q(p)&(l-6e-c+^nqpk'
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# Simple user (basic level)
username_db = "admin"
password_db = "1234"


# 🔑 Create Token
def create_token(username: str):
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)

    payload = {
        "sub": username,
        "exp": expire
    }

    token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
    return token


# 🔐 Login API
@app.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends()):

    if form_data.username == username_db and form_data.password == password_db:
        token = create_token(form_data.username)
        return {"access_token": token, "token_type": "bearer"}

    raise HTTPException(status_code=401, detail="Invalid credentials")


# 🔒 Protected Route
@app.get("/protected")
def protected(token: str = Depends(oauth2_scheme)):

    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")

        return {"message": f"Welcome {username}, protected data accessed"}

    except:
        raise HTTPException(status_code=401, detail="Invalid Token")
    











    
# from fastapi import FastAPI

# app = FastAPI()

# @app.get('/')
# def home():
#     return {"message":"Travelsite Fastapi is running"}