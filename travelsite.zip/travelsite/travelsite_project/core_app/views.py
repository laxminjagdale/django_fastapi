from django.shortcuts import render,redirect
from .models import Destinations
from .forms import ContactForm

# Create your views here.
def home(request):
    return render(request,'core_app/home.html')

def destinations(request):
    places = Destinations.objects.all()
    return render(request,'core_app/destinations.html',{'places':places})

def about(request):
    return render(request,'core_app/about.html')

def contact(request):
    form = ContactForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')
    return render(request,'core_app/contact.html',{'form':form})
